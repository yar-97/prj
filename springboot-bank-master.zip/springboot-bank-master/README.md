RESTful API to simulate simple banking operations. 

## Facilities

*	JPA CRUD operations for customers and accounts.
*	Support deposits and withdrawals on accounts.
*	Internal transfer support (i.e. a customer may transfer funds from one account to another).
*	Add, Find, Update and Delete Customer details
*	View transcation details

## Port Number
 Default port for the api is 9092
	

### Dependencies

```

spring-boot-starter-data-jpa
spring-boot-starter-web
spring-boot-devtools
h2 - Inmemory database
lombok 
springfox-swagger2
springfox-swagger-ui
spring-boot-starter-test
junit-jupiter-api

```

## Swagger

Please find the Rest API documentation in the below url

```
http://localhost:9092/swagger-ui.html#/

```

## H2 In-Memory Database

jdbc:h2:mem:testdb as your jdbc url

```
http://localhost:9092/h2

```

