package com.foundation.sa20123067_bank.doamin;

import javax.validation.constraints.Email;
import javax.validation.constraints.PositiveOrZero;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ContactDetails {

	@Email
	private String emailId;
	@PositiveOrZero
	private String homePhone;
	@PositiveOrZero
	private String workPhone;
	
	public ContactDetails(String emailId, String homePhone, String workPhone) {
		super();
		
		this.emailId=emailId;
		this.homePhone=homePhone;
		this.workPhone=workPhone;
	}
}
