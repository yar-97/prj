package com.foundation.sa20123067_bank.doamin;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class AccountInformation {

	@NotNull(message = "Account Number can't be empty")
	@Size(min=10, max=15)
	private Long accountNumber;
	
	private BankInformation bankInformation;
	
	@NotBlank(message = "Status can't be empty")
	private String accountStatus;
	
	private String accountType;
	
	
	@Min(100)
	private Double accountBalance;
	
	//private Date accountCreated;
}
