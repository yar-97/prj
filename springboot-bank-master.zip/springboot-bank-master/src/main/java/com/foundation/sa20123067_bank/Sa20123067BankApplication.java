package com.foundation.sa20123067_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sa20123067BankApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sa20123067BankApplication.class, args);
	}

}
