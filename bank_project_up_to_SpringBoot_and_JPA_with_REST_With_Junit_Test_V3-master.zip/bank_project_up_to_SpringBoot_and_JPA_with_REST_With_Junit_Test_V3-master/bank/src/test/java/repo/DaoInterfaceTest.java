package repo;



import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import dao.AccountDao;
import domain.Account;
import repo.DaoInterface;

@SpringBootTest(classes = {AccountDao.class})
public class DaoInterfaceTest {
	
	Account ankit;
	Account shweta;
	Account raju;
	List<Account> set;
	@Autowired
	private AccountDao dao;
	
	@MockBean
	private DaoInterface repo;
	
	@BeforeEach
	void init() {
		this.ankit = new Account("ankit", "savings", 5000, "", "", new Date(), true);
		this.shweta = new Account("shweta", "savings", 6000, "", "", new Date(), true);
		this.raju = new Account("raju", "savings", 7000, "", "", new Date(), true);
		set = new ArrayList<Account>();
		set.add(ankit);
		set.add(shweta);
		set.add(raju);
	}
	
	@Test
	public void testCreate1() {
		when(repo.save(ankit)).thenReturn(ankit);
		Account account = dao.create(ankit);
		assertEquals(ankit.isActive(), account.isActive());
	}
	@Test
	public void testCreate2() {
		when(repo.save(shweta)).thenReturn(shweta);
		Account account = dao.create(shweta);
		assertEquals(shweta.isActive(), account.isActive());
	}
	@Test
	public void testCreate3() {
		when(repo.save(raju)).thenReturn(raju);
		Account account = dao.create(raju);
		assertEquals(raju.isActive(), account.isActive());
	}
	@Test
	public void testReadAllCustomers() {
		when(repo.findAll()).thenReturn((List<Account>) set);
		Set<Account> accounts = dao.readAllCustomers();
		assertEquals(set.size(), accounts.size());
	}
	@Test
	public void testIfAccountExists() {
		when(repo.existsById((ankit.getAccountNumber()))).thenReturn(true);
		boolean available = dao.ifAccountExist(ankit.getAccountNumber());
		assertEquals(true, available);
	}
	@Test
	public void testGetSize() {
		when(repo.count()).thenReturn((long) set.size());
		int size = dao.getSize();
		assertEquals(set.size(), size);
	}
	
}
