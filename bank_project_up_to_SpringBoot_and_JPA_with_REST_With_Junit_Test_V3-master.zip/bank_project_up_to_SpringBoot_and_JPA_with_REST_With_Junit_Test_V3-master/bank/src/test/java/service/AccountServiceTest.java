package service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.servlet.ModelAndView;

import dao.AccountDao;
import domain.Account;
import domain.IncompleteAccount;

@SpringBootTest(classes = AccountService.class)
public class AccountServiceTest {

	IncompleteAccount ia1;
	IncompleteAccount ia2;
	IncompleteAccount ia3;
	
	ModelAndView mv;
	
	Account acc1;
	Account acc2;
	Account acc3;
	
	@Autowired
	AccountService service;
	
	@MockBean
	AccountDao dao;
	
	
	@BeforeEach
	void init() {
		mv = new ModelAndView();
		ia1 = new IncompleteAccount("a","b",5000,"a,b,c,d");
		ia2 = new IncompleteAccount("c","d",5000,"a,b,c,d");
		ia3 = new IncompleteAccount("e","f",5000,"a,b,c,d");
		
		 acc1 = new Account("ankit", "savings", 5000, "11", "22", new Date(), true);
		 acc2 = new Account("ankit", "savings", 5000, "11", "22", new Date(), true);
		 acc3 = new Account("ankit", "savings", 5000, "11", "22", new Date(), true);
	}
	
	
	
	@Test
	public void createTest() {
		when(dao.create(acc1)).thenReturn(acc1);
		assertEquals(acc1.getAccountNumber(), dao.create(acc1).getAccountNumber());
	}
	
	@Test
	public void getBalanceTest() {
		when(dao.getBalance(acc1.getAccountNumber())).thenReturn(acc1.getBalance());
		assertThat(acc1.getBalance()).isEqualTo(service.findAccountBalance(acc1.getAccountNumber()));
	}
	
	@Test
	public void processFundTransferTest() {
		when(dao.ifAccountExist(acc1.getAccountNumber())).thenReturn(true);
		when(dao.getBalance(acc1.getAccountNumber())).thenReturn(acc1.getBalance());
		assertThat(service.processFundTransfer(acc1.getAccountNumber(), acc2.getAccountNumber(), 2000)).isEqualTo("Transaction successful");
	}
}
