package dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import domain.Account;
import repo.DaoInterface;

@Component
public class AccountDao {

	@Autowired
	private DaoInterface dao;
	
	public Account create(Account acct) {
		Account account = dao.save(acct);
		return account;
	}

	public int getSize() {
		int size = (int) dao.count();
		return size;
	}

	public Set<Account> readCustomerByJointAccount() {
		// TODO Auto-generated method stub
		return null;
	}

	public double getBalance(String acctNumber) {
		Account account = dao.findById(acctNumber).orElse(null);
		double balance = -1;
		balance = account.getBalance();
		return balance;
	}

	public boolean ifAccountExist(String account_number) {
		boolean available = dao.existsById(account_number);
		return available;
	}

	public int updateAccountBalance(String account_number, double new_balance) {
		Account account = dao.findById(account_number).orElse(null);
		account.setBalance(new_balance);
		dao.save(account);
		return 0;
	}

	public Set<Account> readAllCustomers() {
		ArrayList<Account> list = (ArrayList<Account>) dao.findAll();
		return new HashSet<Account>(list);
	}


}
