package service;

import java.text.SimpleDateFormat;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.AccountDao;
import domain.Account;
import domain.IncompleteAccount;

@Service
public class AccountService implements AccountInterface {

	@Autowired
    AccountDao acc;

    private Account createAccount(IncompleteAccount ia) {
    	Account account =  new Account("","",0,"","",new Date(),true);
    	
    	Date date = new Date();
    	String account_number = generateAccountNumber(ia.getName());
    	boolean isActive = true;
    	account = acc.create(new Account(
    			ia.getName(), 
    			ia.getAccountType(),
    			ia.getBalance(), 
    			account_number, 
    			ia.getAccountOwners(),
    			date,
    			isActive
    			));
    	return account;
    }

	@Override
    public Set<Account> findCustomersByType(String acctType) {
        return null;
    }

 
    private String generateAccountNumber(String name){
        String number;
        int num  = acc.getSize();
        num++;
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMMYYYY");
        String date = sdf.format(new Date());
        number = name.substring(0,2)+date+num;
        number = number.toUpperCase();
        return number;
    }

    @Override
    public Set<Account> findJointAccountCustomers() {
        Set<Account> set_of_accounts;
        set_of_accounts = acc.readCustomerByJointAccount();
        return set_of_accounts;
    }

    @Override
    public double findAccountBalance(String acctNumber) {
        double balance;
        balance = acc.getBalance(acctNumber);
        return balance;
    }

    @Override
    public String processFundTransfer(String fromAccount, String toAccount, double amount) {
        String result ;
        int code;
        if (amount > 0)
            if(acc.ifAccountExist(fromAccount))
                if(acc.ifAccountExist(toAccount)){
                    double bal = acc.getBalance(fromAccount);
                    if(bal >= amount){
                        code = acc.updateAccountBalance(fromAccount, bal - amount);
                        if(code == 0)
                            code = acc.updateAccountBalance(toAccount, acc.getBalance(toAccount) + amount);
                    }
                    else
                        code = 3;
                }
                else
                    code = 2;
            else
                code = 1;
        else
             code = -1;

        result = result(code);
        return result;
    }

    @Override
    public Set<Account> findAllCustomers() {
    	Set<Account> set = null;
    	try {
    		set  = acc.readAllCustomers();
    	}
    	catch(NullPointerException e) {
    		e.printStackTrace();
    	}
    	return set;
    }

    private String result(int code)
    {
        String result ;
        if(code == -1)
            result = "Amount can't be 'Zero' or 'Negative'.";
        else if(code == 1)
            result = "Sender's Account not found";
        else if(code == 2)
            result = "Receiver's Account not found";
        else if(code == 3)
            result = "Insufficient amount";
        else if(code == 4)
            result = "Update failed";
        else
            result = "Transaction successful";
        return result;
    }

    @Override
	public Account addCustomer(IncompleteAccount ia) {
		Account account = new Account("","",0,"","",new Date(),true);
		if(ia.getBalance() >= 500)
			account = createAccount(ia);
		return account;
	}

}