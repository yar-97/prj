package service;

import java.util.Set;

import domain.Account;
import domain.IncompleteAccount;

public interface AccountInterface {
	    Set<Account> findCustomersByType(String acctType);
	    double findAccountBalance(String acctNumber);
	    String processFundTransfer(String fromAcct, String toAcct, double amount);
	    Set<Account> findAllCustomers();
	    public Set<Account> findJointAccountCustomers();
	    public Account addCustomer(IncompleteAccount ia);
	   
}
