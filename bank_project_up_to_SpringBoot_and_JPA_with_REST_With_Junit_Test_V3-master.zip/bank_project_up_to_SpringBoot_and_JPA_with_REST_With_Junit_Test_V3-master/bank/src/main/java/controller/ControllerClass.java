package controller;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import domain.Account;
import domain.IncompleteAccount;
import service.AccountService;

@RestController
public class ControllerClass implements ControllerInterfce{
	
	@Autowired
	AccountService service;

	@Override
	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}
	
	@Override
	@PostMapping(path = "/create")
	public ModelAndView create(IncompleteAccount ia) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("create");
		Account account = null;
		account = service.addCustomer(ia);
		mv.addObject("account", account);
        return mv;
	}	
	
	@Override
	@GetMapping("/create")
	public ModelAndView create() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("create");
        return mv;
	}
	
	@Override
	@GetMapping("account_balance")
	public ModelAndView account_balance() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("account_balance");
        return mv;
	}
	
	@Override
	@PostMapping("account_balance")
	public ModelAndView account_balance(String accno) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("account_balance");
		double balance = service.findAccountBalance(accno);
		mv.addObject("balance", balance);
		return mv;
	}
	
	@Override
	@GetMapping("find_all_customers")
	public ModelAndView find_all_customers() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("find_all_customers");
		Set<Account> customers =  service.findAllCustomers();
		mv.addObject("accounts", customers);
		return mv;
	}
	
	@Override
	@GetMapping("fund_transfer")
	public ModelAndView fund_transfer() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("fund_transfer");
		return mv;
	}
	@Override
	@PostMapping("fund_transfer")
	public ModelAndView fund_transfer(String sno, String rno, double amount) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("fund_transfer");
		String result = service.processFundTransfer(sno, rno, amount);
		mv.addObject("confirmation", result);
		return mv;
	}
	
	@Override
	@RequestMapping("find_joint_account")
	public ModelAndView find_joint_account() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("find_joint_account");
		return mv;
	}
	
	@Override
	@RequestMapping("find_by_type")
	public ModelAndView find_by_type() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("find_by_type");
		return mv;
	}
	
}
