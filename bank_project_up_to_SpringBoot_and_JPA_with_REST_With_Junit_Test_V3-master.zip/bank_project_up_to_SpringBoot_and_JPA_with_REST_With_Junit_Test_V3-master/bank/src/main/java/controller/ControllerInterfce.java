package controller;

import org.springframework.web.servlet.ModelAndView;

import domain.IncompleteAccount;

public interface ControllerInterfce {
	ModelAndView index();
	ModelAndView create(IncompleteAccount ia);
	ModelAndView create();
	ModelAndView find_all_customers();
	ModelAndView fund_transfer();
	ModelAndView find_joint_account();
	ModelAndView find_by_type();
	ModelAndView account_balance(String accno);
	ModelAndView account_balance();
	ModelAndView fund_transfer(String sno, String rno, double amount);
}
