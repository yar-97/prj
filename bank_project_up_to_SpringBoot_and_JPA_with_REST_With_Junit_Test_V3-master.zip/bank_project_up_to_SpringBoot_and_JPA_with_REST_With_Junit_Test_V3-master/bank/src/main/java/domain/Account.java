package domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "BANK_ACCOUNT")
public class Account{

	private String name;
    private String accountType;
    private double balance;
    @Id
    private String accountNumber;
    private String accountOwners;
    private Date joiningDate;
    private boolean isActive;
    
    
    public Account() {
    	super();
		this.name = "";
		this.accountType = "";
		this.balance = 0.0;
		this.accountNumber = "";
		this.accountOwners = "";
		this.joiningDate = null;
		this.isActive = false;
    }
    
    public Account(String name, String accountType, double balance, String accountNumber, String accountOwners,
			Date joiningDate, boolean isActive) {
		super();
		this.name = name;
		this.accountType = accountType;
		this.balance = balance;
		this.accountNumber = accountNumber;
		this.accountOwners = accountOwners;
		this.joiningDate = joiningDate;
		this.isActive = isActive;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountOwners() {
		return accountOwners;
	}

	public void setAccountOwners(String accountOwners) {
		this.accountOwners = accountOwners;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

    @Override
	public String toString() {
		return "Account [name=" + name + ", accountType=" + accountType + ", balance=" + balance + ", accountNumber="
				+ accountNumber + ", accountOwners=" + accountOwners + ", joiningDate=" + joiningDate + ", isActive="
				+ isActive + "]";
	}
}
