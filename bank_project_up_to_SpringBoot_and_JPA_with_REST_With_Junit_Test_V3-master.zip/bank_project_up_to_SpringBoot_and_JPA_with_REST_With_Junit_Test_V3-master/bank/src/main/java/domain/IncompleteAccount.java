package domain;

public class IncompleteAccount {
	private String name;
    private String accountType;
    private double balance;
    private String accountOwners;
    
	public IncompleteAccount() {
		super();
	}
	public IncompleteAccount(String name, String accountType, double balance, String accountOwners) {
		super();
		this.name = name;
		this.accountType = accountType;
		this.balance = balance;
		this.accountOwners = accountOwners;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccountOwners() {
		return accountOwners;
	}
	public void setAccountOwners(String accountOwners) {
		this.accountOwners = accountOwners;
	}
}
