EndPoints		Responses
	
addAccount()  - Saves account object to H2 database	
	
getAllAccounts()  - Fetches all accounts from H2 database	
	
getAllCustomers()  - Fetches all customers from H2 database

transferFunds(fromAcc, toAcc, amount)	- Transfers funds from one account to another

getBalanceOf()  - Fetches all account details for a given account number
