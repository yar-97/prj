package com.wipro.bank.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.bank.bean.Customer;
import com.wipro.bank.repo.CustomerRepo;

@Service
public class CustomerDao{

	@Autowired
	CustomerRepo customerRepo;
	
	public List<Customer> findAllCustomers(){
		return customerRepo.findAll();
	}
}
