package com.wipro.bank.bean;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="ACCOUNT")
public class Account implements Serializable{
	@Id	
	@NotNull
	@Column(name="accountID")
	private int accountID;
	//private Customer customer;
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "customerID")
	private Customer customer;
	
	@Column(name="balance")
	private double balance;
	
	public int getAccountID() {
		return this.accountID;
	}
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}
	/*public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}*/
	public double getBalance() {
		return this.balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	public Account (){
		super();
	}	
	
	public Customer getCustomer() {
		return this.customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	/*
	 * public Account(int accID, Customer cust, double balnc){ accountID = accID;
	 * customer_Id = cust.getCustomerID(); //customer = cust;//new
	 * Customer(customer.getCustomerID(), customer.getName()); balance = balnc;
	 * AccountDto accountDto = new AccountDto(); accountDto.saveAccount(this); }
	 */
	public Account(int accountID, Customer customer_Id, double balance) {
		super();
		this.accountID = accountID;
		this.customer = customer_Id;
		this.balance = balance;
	}

}
