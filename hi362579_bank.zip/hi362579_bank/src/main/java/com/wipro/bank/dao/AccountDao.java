package com.wipro.bank.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.bank.bean.Account;
import com.wipro.bank.repo.AccountRepo;

@Service
public class AccountDao{
	
	@Autowired
	AccountRepo accRepo;
	
	public Account saveAcount(Account acc){
		accRepo.save(acc);
		return acc;
	}
	
	public List<Account> findAllAcount(){
		return accRepo.findAll();
	}
}
