package com.wipro.bank.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.bank.bean.Account;
import com.wipro.bank.bean.Customer;
import com.wipro.bank.dao.AccountDao;
import com.wipro.bank.dao.CustomerDao;

@RestController
@RequestMapping("/accounts/")
public class AccountService {	

	@Autowired
	AccountDao accountDao;
	
	@Autowired
	CustomerDao customerDao;
	
	@GetMapping("/")
	public ResponseEntity<String> getWelcomePage() {
		return ResponseEntity.ok("Welcome to default response");
	}
	
	@PostMapping("/add_account")
	public int addAccount (@Valid @RequestBody Account acc){
		int accountID = -1;
		Account accnt = accountDao.saveAcount(acc);
		if(accnt != null){
			accountID = accnt.getAccountID();
		}
		return accountID;
	}
	public List<Account> getAllAccounts(){
		return accountDao.findAllAcount();
	}
	public List<Customer> getAllCustomers(){
		return customerDao.findAllCustomers();
		
	}
	public String transferFunds(int	from,int to,double amount){
		String retVal = null;
		Account payer = null;
		Account beneficiary = null;
		List<Account> accounts = getAllAccounts();
		for (Account acc : accounts) {
			if(acc.getAccountID() == from) 
				payer = acc;
			if(acc.getAccountID() == to) 
				beneficiary = acc;
		}
		if(null != payer && null != beneficiary) {
			if(payer.getBalance() < amount)
				retVal = "INSUFFICIENT FUNDS";
			else {
				payer.setBalance(payer.getBalance() - amount);
				beneficiary.setBalance(beneficiary.getBalance() + amount);
				accountDao.saveAcount(payer);
				accountDao.saveAcount(beneficiary);
				retVal = "SUCCESS";
			}
		} else {
			retVal = "ID MISMATCH";
		}
		
		return retVal;		
	}
	
	public Account getBalanceOf(int	accountNumber){
		Account retVal = null;
		List<Account> accounts = this.getAllAccounts();
		for(Account acc : accounts){
			if(acc.getAccountID() == accountNumber)
				retVal = acc;
		}		
		return retVal;
	}

}
