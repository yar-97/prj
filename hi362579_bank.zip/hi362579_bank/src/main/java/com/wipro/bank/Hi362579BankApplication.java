package com.wipro.bank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.wipro.bank.service.AccountService;

@SpringBootApplication
@ComponentScan
//public class Hi362579BankApplication implements CommandLineRunner{
public class Hi362579BankApplication{

	@Autowired
	AccountService accountService;
	
	public static void main(String[] args){
		SpringApplication.run(Hi362579BankApplication.class, args);
		
	}

/*	@Override
	public void run(String... args) throws Exception {
		List<Account> accounts=new ArrayList<Account>();
		Account acc1=new Account(1,new Customer(1,"cust1"),100.0);
		Account acc2=new Account(2,new Customer(2,"cust2"),0.0);
		Account acc4=new Account(4,new Customer(4,"cust4"),123.0);
		Account acc5=new Account(5,new Customer(5,"cust5"),984.0);
		accountService.addAccount(acc1);
		accountService.addAccount(acc2);
		accountService.addAccount(acc4);
		accountService.addAccount(acc5);
		accounts.add(acc1);
		accounts.add(acc2);
		accounts.add(acc4);
		accounts.add(acc5);
		//accountService.defineDB(accounts);
		System.out.println("************** Get All Accounts *****************");
		System.out.println(accountService.getAllAccounts().get(0).getCustomer().getName());
		System.out.println("\n************** Get All Customers *****************");
		System.out.println(accountService.getAllCustomers().get(0).getName());
		Account userTest1=accountService.getBalanceOf(acc1.getAccountID());
		System.out.println("\n@ Account balance of account number:"+acc1.getAccountID()+" is :"+"\n## "+userTest1.getBalance());
		userTest1=accountService.getBalanceOf(acc4.getAccountID());
		System.out.println("\n@ Account details of account number:"+acc4.getAccountID()+" is as follows"+"\n##"+userTest1);
		System.out.println("\n########## Account Balance for given account number ##########");
		Account userTest2=accountService.getBalanceOf(3);
		System.out.println("@ Account details of account number:3 .."+"## "+userTest2+" sorry user doesn't exist\n");
		System.out.println("############ All Customer Details ############");
		System.out.println(accountService.getAllCustomers());
		System.out.println("\n ############ Transfer of Funds from account number 4 to 5 ############");
		String transferStatus=accountService.transferFunds(4,5,100);
		System.out.println("@ Fund Transfer from account 4 to account 5 is: "+transferStatus);
		transferStatus=accountService.transferFunds(4,5,100);
		System.out.println("@ Response of fund transfer when funds are in sufficient : "+transferStatus);
		userTest1=accountService.getBalanceOf(4);
		System.out.println("@ Available balance for account number: 4 is"+"\n## "+userTest1);
		userTest1=accountService.getBalanceOf(5);
		System.out.println("@ Account details of account number: 5 is"+"\n## "+userTest1);
		System.out.println("*******************************************************\n");
		Customer cust3=new Customer(3,"cust3");
		Account acc3=new Account(9,cust3,0.0);
		System.out.println("New Customer & Account created: "+accountService.addAccount(acc3));
		System.out.println("\n************** Get All Customers *****************");
		System.out.println(accountService.getAllCustomers());
		Account account1;
		account1 = new Account(201,new Customer(101,"cust1"),100.0);		
		int result = accountService.addAccount(account1);
		System.out.println("The Account ID: "+result);
		
	}*/

}
