package com.wipro.bank.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="CUSTOMER")
public class Customer implements Serializable{
	@Id
	@NotNull
	@Column(name="customerID")
	private int customerID;
	private String name;
	
	public Customer (){
		super();
	}	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	public Customer(int customerID, String name) {
		super();
		this.customerID = customerID;
		this.name = name;
	}

	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
}
