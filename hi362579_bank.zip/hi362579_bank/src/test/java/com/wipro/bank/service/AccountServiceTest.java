package com.wipro.bank.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wipro.bank.bean.Account;
import com.wipro.bank.bean.Customer;
import com.wipro.bank.dao.AccountDao;

@RunWith(SpringRunner.class)
@SpringBootTest
@DataJpaTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountServiceTest {

	@Autowired
	AccountService accountService;
	@Autowired
	AccountDao accountDao;
	
	public AccountServiceTest() {
		
	}
	
	@Test
	public void testRecordsWhenEmpty() {
	Iterable<Account> accounts = accountDao.findAllAcount();
	assertThat(accounts).isEmpty();
	}
	
	@Test
	public void addAccount() {
		Account account1;
		account1 = new Account(201,new Customer(101,"cust1"),100.0);
		Account acc = accountDao.saveAcount(account1);		
		assertThat(acc.getAccountID()).isEqualTo(201);
	}
	
	@Test
	public void getAllAccountsTest() {
		Account account1, account2, account3;
		account1 = new Account(202,new Customer(102,"cust2"),1000.0);
		accountDao.saveAcount(account1);
		account2 = new Account(203,new Customer(103,"cust3"),2500.0);
		accountDao.saveAcount(account2);
		account3 = new Account(204,new Customer(104,"cust4"),2500.0);
		accountDao.saveAcount(account3);
		List<Account> accounts = new ArrayList<>();
		accounts.add(account1);
		accounts.add(account2);
		accounts.add(account3);		
		assertThat(accountDao.findAllAcount().size()).isEqualTo(3);
	}
	
	@Test
	public void transferFundsTest() {
		Account account1, account2;
		account1 = new Account(205,new Customer(105,"cust5"),1000.0);
		accountDao.saveAcount(account1);
		account2 = new Account(206,new Customer(106,"cust6"),2500.0);
		accountDao.saveAcount(account2);
				
		assertThat(accountService.transferFunds(account1.getAccountID(), account2.getAccountID(), 1500.0)).isEqualTo("INSUFFICIENT FUNDS");
		assertThat(accountService.transferFunds(account1.getAccountID(), 10, 500.0)).isEqualTo("ID MISMATCH");
		assertThat(accountService.transferFunds(account1.getAccountID(), account2.getAccountID(), 500.0)).isEqualTo("SUCCESS");
		assertThat(accountService.getBalanceOf(account1.getAccountID()).getBalance()).isEqualTo(500);
		assertThat(accountService.getBalanceOf(account2.getAccountID()).getBalance()).isEqualTo(3000);
	}
	
	@Test
	public void getBalanceTest() {
		Account account1;
		account1 = new Account(204,new Customer(104,"cust4"),1500.0);
		accountDao.saveAcount(account1);
		Account result = accountService.getBalanceOf(account1.getAccountID());
		assertThat(result.getAccountID()).isEqualTo(204);
	}
}